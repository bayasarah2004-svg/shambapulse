/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: Date;
}

export interface MarketTrend {
  commodity: string;
  currentPrice: number;
  predictedPrice: number;
  trend: 'up' | 'down' | 'stable';
  confidence: number;
  history: { date: string; price: number }[];
}

export type CommodityType = 'Maize' | 'Beans' | 'Tomatoes' | 'Onions' | 'Potatoes';
