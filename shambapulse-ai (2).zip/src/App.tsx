/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { MarketDashboard } from './components/MarketDashboard';
import { ChatWindow } from './components/ChatWindow';
import { MarketTrend } from './types';
import { Sprout, LayoutDashboard, MessageCircle, Info, Menu, X, Landmark } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';

const MOCK_TRENDS: MarketTrend[] = [
  {
    commodity: 'White Maize (90kg Bag)',
    currentPrice: 4200,
    predictedPrice: 4800,
    trend: 'up',
    confidence: 0.85,
    history: [
      { date: 'Apr 10', price: 3800 },
      { date: 'Apr 15', price: 3950 },
      { date: 'Apr 20', price: 4100 },
      { date: 'Apr 25', price: 4200 },
    ]
  },
  {
    commodity: 'Beans (Rose Coco)',
    currentPrice: 12500,
    predictedPrice: 11800,
    trend: 'down',
    confidence: 0.72,
    history: [
      { date: 'Apr 10', price: 13000 },
      { date: 'Apr 15', price: 12800 },
      { date: 'Apr 20', price: 12600 },
      { date: 'Apr 25', price: 12500 },
    ]
  }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'chat'>('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-editorial-bg text-editorial-text font-serif">
      {/* Mobile Header */}
      <header className="md:hidden flex items-center justify-between p-6 bg-editorial-bg border-b border-editorial-border z-30">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-editorial-primary rounded-full"></div>
          <span className="text-xl font-bold tracking-tight uppercase font-sans italic text-editorial-primary">ShambaPulse</span>
        </div>
        <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 text-editorial-muted">
          {isSidebarOpen ? <X /> : <Menu />}
        </button>
      </header>

      {/* Sidebar Navigation - Reimagined as "Market Intelligence" aside */}
      <nav className={cn(
        "fixed md:relative inset-y-0 left-0 w-[320px] bg-editorial-sidebar md:bg-editorial-sidebar border-r border-editorial-border z-40 transition-transform duration-300 transform md:translate-x-0 p-10 flex flex-col gap-10 shadow-none",
        isSidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        {/* Logo Section */}
        <div className="hidden md:flex items-center gap-2">
          <div className="w-8 h-8 bg-editorial-primary rounded-full"></div>
          <span className="text-2xl font-bold tracking-tight uppercase font-sans italic text-editorial-primary">ShambaPulse</span>
        </div>

        <section>
          <h3 className="text-[10px] uppercase tracking-[0.2em] text-editorial-muted font-sans font-bold mb-6">Intelligence</h3>
          <div className="flex flex-col gap-3">
            <NavItem 
              active={activeTab === 'dashboard'} 
              onClick={() => { setActiveTab('dashboard'); setIsSidebarOpen(false); }}
              icon={<LayoutDashboard className="w-4 h-4" />}
              label="MARKET TRENDS"
            />
            <NavItem 
              active={activeTab === 'chat'} 
              onClick={() => { setActiveTab('chat'); setIsSidebarOpen(false); }}
              icon={<MessageCircle className="w-4 h-4" />}
              label="AI NEGOTIATOR"
            />
          </div>
        </section>

        <section className="mt-8">
           <h3 className="text-[10px] uppercase tracking-[0.2em] text-editorial-muted font-sans font-bold mb-6">Price Pulse</h3>
           <div className="space-y-6">
              {MOCK_TRENDS.slice(0, 2).map((trend) => (
                <div key={trend.commodity} className="flex items-end justify-between border-b border-editorial-border pb-2">
                  <div>
                    <p className="text-[11px] font-sans font-bold text-editorial-primary uppercase">{trend.commodity.split(' ')[0]}</p>
                    <p className="text-2xl font-serif">KSh {trend.currentPrice.toLocaleString()}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] text-editorial-primary font-sans font-bold uppercase">Forecast</p>
                    <p className={cn("text-base font-serif", trend.trend === 'up' ? "text-editorial-secondary" : "text-editorial-muted")}>
                      {trend.trend === 'up' ? '+' : '-'}{Math.round((Math.abs(trend.predictedPrice - trend.currentPrice) / trend.currentPrice) * 100)}%
                    </p>
                  </div>
                </div>
              ))}
           </div>
        </section>

        <div className="mt-auto">
          <div className="p-6 bg-editorial-primary text-editorial-bg rounded-2xl">
            <p className="font-sans text-[11px] uppercase tracking-wider mb-2 opacity-80">Market Alert</p>
            <h4 className="text-xl mb-4 leading-tight font-serif italic font-normal">Prices in Nakuru are peaking. Sell now.</h4>
            <div className="w-12 h-[2px] bg-editorial-secondary"></div>
          </div>
        </div>
      </nav>

      {/* Overlay for mobile sidebar */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-stone-900/10 backdrop-blur-[2px] z-30 md:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Main Content */}
      <main className="flex-1 p-8 md:px-16 md:py-12 flex flex-col max-w-7xl mx-auto w-full overflow-y-auto">
        {/* Welcome Section */}
        <div className="mb-10">
          <span className="text-[11px] font-sans font-bold uppercase tracking-[0.3em] text-editorial-secondary">Market Negotiator AI</span>
          <motion.h1 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-6xl md:text-7xl font-light leading-[1.0] mt-4 mb-2 font-serif"
          >
            Habari, Mkulima.
          </motion.h1>
          <p className="text-xl text-editorial-muted italic font-serif mt-4">
            "Niambie, unataka kuuza nini leo? I can help you get the best price."
          </p>
        </div>

        <div className="flex-1 min-h-0">
          <AnimatePresence mode="wait">
             {activeTab === 'dashboard' ? (
                <motion.div
                  key="dashboard"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="h-full"
                >
                  <MarketDashboard trends={MOCK_TRENDS} />
                </motion.div>
             ) : (
                <motion.div
                  key="chat"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="h-full max-w-5xl mx-auto w-full"
                >
                  <div className="h-[600px]">
                    <ChatWindow />
                  </div>
                </motion.div>
             )}
          </AnimatePresence>
        </div>

        <div className="mt-8 flex justify-between items-center text-editorial-muted font-sans text-[10px] tracking-widest uppercase font-bold border-t border-editorial-border pt-6">
          <span>Data sourced from National Cereals & Produce Board</span>
          <div className="flex-1 text-center hidden md:block border-x border-editorial-border mx-8 px-4 h-4 flex items-center justify-center">
            <div className="text-[9px] italic font-normal tracking-normal text-editorial-muted/60">Live from Wakulima Market</div>
          </div>
          <span className="flex items-center gap-2"><span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span> Pulse Online</span>
        </div>
      </main>
    </div>
  );
}

function NavItem({ active, onClick, icon, label }: { 
  active: boolean, 
  onClick: () => void, 
  icon: React.ReactNode, 
  label: string 
}) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex items-center justify-between w-full p-2 h-8 transition-all duration-300 group font-sans text-[11px] font-bold tracking-widest uppercase border-b border-transparent",
        active 
          ? "text-editorial-text border-editorial-text" 
          : "text-editorial-muted hover:text-editorial-text"
      )}
    >
      <div className="flex items-center gap-3">
        <span className={cn(active ? "text-editorial-primary" : "text-editorial-muted group-hover:text-editorial-primary")}>
          {icon}
        </span>
        <span>{label}</span>
      </div>
    </button>
  );
}

