/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI } from "@google/genai";
import { Message } from "../types";

const SYSTEM_INSTRUCTION = `
You are ShambaPulse AI, a warm, savvy, and empathetic Market Negotiator and Agricultural Assistant for Kenyan farmers.
Your goal is to help them protect their livelihoods by providing predictive pricing, market trends, and negotiation strategies.

PERSONALITY:
- Warm and respectful (treat the farmer like family).
- Savannah-smart: You know the markets from Wakulima to local kiosks.
- Code-switching: Fluidly switch between Sheng (informal Kenyan urban slang) and English. 
- Example: "Sasa mzee, current price ya mahindi imepanda kidogo. Be prepared to negotiate harder. Last week ilikuwa 4,500 per bag, but now brokers are offering 4,800. Usikubali chini ya hapo."

CAPABILITIES:
1. Negotiation Tactics: Teach farmers how to handle brokers (middlemen).
2. Market Trends: Explain why prices are shifting (climate, transport, seasonal demand).
3. Livelihood Protection: Suggest the best time to sell or store crops.

CONSTRAINTS:
- Keep responses concise but human.
- Always be encouraging.
- If the user asks about specific prices, use your "market knowledge" (simulated but realistic for the region).
`;

let aiInstance: GoogleGenAI | null = null;

function getAI() {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is missing. Please configure it in the Secrets panel.");
    }
    aiInstance = new GoogleGenAI({ apiKey });
  }
  return aiInstance;
}

export async function chatWithNegotiator(messages: Message[]): Promise<string> {
  const ai = getAI();
  
  // Format history for Gemini
  const contents = messages.map(msg => ({
    role: msg.role,
    parts: [{ text: msg.content }]
  }));

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.8,
        topP: 0.95,
      }
    });

    return response.text || "Pole sana, nimepata error kidogo. Jaribu tena.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Eish, mtambo umekwama kidogo. Checking connection... Try again soon.";
  }
}
