/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Send, Mic, User, Bot, Sparkles, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Message } from '../types';
import { chatWithNegotiator } from '../services/geminiService';
import { cn } from '../lib/utils';

export const ChatWindow: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'model',
      content: "Sasa mzee! Mimi ni ShambaPulse. I'm here to help you get the best deals for your crops. What's on your farm today? Unasumbuliwa na nini kwa market?",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isTyping) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    try {
      const response = await chatWithNegotiator([...messages, userMessage]);
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        content: response,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMessage]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-[40px] shadow-sm border border-editorial-border overflow-hidden relative">
      {/* Chat header */}
      <div className="px-10 py-6 border-b border-editorial-border bg-editorial-sidebar/30 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-editorial-primary flex items-center justify-center text-white text-[10px] font-bold tracking-tighter">
            RAFIKI
          </div>
          <div>
            <h3 className="font-serif italic font-bold text-editorial-text leading-tight">ShambaPulse Agent</h3>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              <span className="text-[9px] text-editorial-muted font-sans font-bold uppercase tracking-[0.2em]">Agent Online</span>
            </div>
          </div>
        </div>
        <div className="text-[10px] font-sans font-bold text-editorial-secondary uppercase tracking-widest border border-editorial-border px-3 py-1 rounded-full">
           Strategic Negotiation
        </div>
      </div>

      {/* Messages */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-8 md:p-10 space-y-8 scroll-smooth bg-white"
      >
        <AnimatePresence>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "flex gap-4 max-w-[85%]",
                msg.role === 'user' ? "ml-auto flex-row-reverse" : "mr-auto"
              )}
            >
              <div className={cn(
                "w-10 h-10 rounded-full grow-0 shrink-0 flex items-center justify-center font-bold text-[10px] tracking-tighter",
                msg.role === 'user' ? "bg-editorial-text text-white" : "bg-editorial-primary text-white"
              )}>
                {msg.role === 'user' ? 'YOU' : 'PULSE'}
              </div>
              <div className={cn(
                "px-8 py-5 rounded-[32px] text-lg font-serif leading-relaxed shadow-sm border border-editorial-border",
                msg.role === 'user' 
                  ? "bg-editorial-accent-bg text-editorial-text rounded-tr-none italic border-none" 
                  : "bg-white text-editorial-text rounded-tl-none font-normal"
              )}>
                {msg.role === 'model' && msg.content.includes("Sasa mzee") ? (
                  <span>
                    <span className="font-bold text-editorial-primary">Sasa mzee!</span> {msg.content.replace("Sasa mzee!", "")}
                  </span>
                ) : msg.content}
                <div className={cn(
                  "text-[8px] mt-3 opacity-40 uppercase tracking-widest font-sans font-bold text-editorial-muted",
                  msg.role === 'user' ? "text-right" : "text-left"
                )}>
                  MARKET TIME: {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </motion.div>
          ))}
          {isTyping && (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              className="flex items-center gap-3 text-editorial-muted font-sans text-[10px] font-bold uppercase tracking-widest ml-14"
            >
              <div className="flex gap-1.5 Items-center">
                 <span className="w-1.5 h-1.5 bg-editorial-primary rounded-full animate-pulse"></span>
                 <span className="w-1.5 h-1.5 bg-editorial-primary rounded-full animate-pulse delay-75"></span>
                 <span className="w-1.5 h-1.5 bg-editorial-primary rounded-full animate-pulse delay-150"></span>
              </div>
              <span className="italic opacity-60">ShambaPulse is scanning price lists...</span>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Input */}
      <div className="p-8 bg-editorial-sidebar/50 border-t border-editorial-border">
        <form onSubmit={handleSend} className="relative flex items-center gap-4">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type here or speak to negotiate..."
            className="flex-1 bg-white border border-editorial-border rounded-full px-10 py-5 text-lg font-serif italic text-editorial-text placeholder:text-editorial-muted/50 focus:outline-none focus:ring-4 focus:ring-editorial-primary/5 focus:border-editorial-primary transition-all shadow-sm"
          />
          <button 
            type="submit"
            disabled={!input.trim() || isTyping}
            className="w-16 h-16 bg-editorial-primary text-white rounded-full flex items-center justify-center hover:bg-editorial-primary/95 transition-all shadow-xl shadow-editorial-primary/20 disabled:grayscale disabled:opacity-30 disabled:shadow-none shrink-0 group"
          >
            {isTyping ? <AlertCircle className="w-6 h-6 animate-spin" /> : <Mic className="w-7 h-7 group-hover:scale-110 transition-transform" />}
          </button>
        </form>
        <p className="text-[10px] text-editorial-muted mt-6 text-center flex items-center justify-center gap-3 font-sans font-bold uppercase tracking-[0.2em] opacity-60">
          <span className="w-1 h-1 bg-editorial-secondary rounded-full" />
          Strategic Market Intelligence System
          <span className="w-1 h-1 bg-editorial-secondary rounded-full" />
        </p>
      </div>
    </div>
  );
};
