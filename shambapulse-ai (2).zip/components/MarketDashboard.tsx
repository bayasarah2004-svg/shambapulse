/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { TrendingUp, TrendingDown, Info, Wallet } from 'lucide-react';
import { MarketTrend } from '../types';
import { formatCurrency, cn } from '../lib/utils';
import { motion } from 'motion/react';

interface MarketDashboardProps {
  trends: MarketTrend[];
}

export const MarketDashboard: React.FC<MarketDashboardProps> = ({ trends }) => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 bg-editorial-bg">
      <div className="space-y-10">
        <section>
          <div className="flex items-center justify-between mb-8 pb-4 border-b border-editorial-border">
            <h2 className="text-[12px] font-bold text-editorial-muted flex items-center gap-2 uppercase tracking-[0.2em] font-sans">
              Market Intelligence
            </h2>
            <span className="text-[10px] font-sans font-bold uppercase tracking-wider text-editorial-secondary bg-editorial-accent-bg px-3 py-1 rounded-full">Live Stats</span>
          </div>
          <div className="grid grid-cols-1 gap-6">
            {trends.map((trend) => (
              <motion.div
                key={trend.commodity}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="group cursor-pointer"
              >
                <div className="flex justify-between items-end border-b border-editorial-border pb-3 group-hover:border-editorial-primary transition-colors">
                  <div>
                    <span className="text-[11px] font-sans font-bold text-editorial-muted uppercase tracking-wider group-hover:text-editorial-primary transition-colors">{trend.commodity}</span>
                    <div className="text-4xl font-serif text-editorial-text mt-1 leading-none">
                      {formatCurrency(trend.currentPrice)}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] text-editorial-primary font-sans font-bold uppercase tracking-tighter mb-1">Forecast</p>
                    <div className={cn(
                       "text-xl font-serif leading-none",
                       trend.trend === 'up' ? 'text-editorial-secondary' : 'text-editorial-muted'
                    )}>
                      {trend.trend === 'up' ? '+' : '-'}{Math.round((Math.abs(trend.predictedPrice - trend.currentPrice) / trend.currentPrice) * 100)}%
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-between mt-2">
                   <span className="text-[9px] text-editorial-muted font-sans font-bold uppercase tracking-widest italic opacity-60">Confidence Index</span>
                   <div className="flex items-center gap-1.5 min-w-[60px]">
                      <div className="flex-1 bg-editorial-border h-[2px]">
                         <div 
                           className="bg-editorial-primary h-full transition-all duration-1000" 
                           style={{ width: `${trend.confidence * 100}%` }}
                         />
                      </div>
                      <span className="text-[10px] font-sans font-bold text-editorial-primary">{Math.round(trend.confidence * 100)}%</span>
                   </div>
                </div>
              </motion.div>
            ))}
          </div>
        </section>

        <div className="p-8 bg-editorial-sidebar border border-editorial-border rounded-xl relative overflow-hidden">
          <div className="relative z-10">
            <h3 className="text-[10px] font-sans font-bold uppercase tracking-[0.2em] text-editorial-secondary mb-4">
              AI Strategist Tip
            </h3>
            <p className="text-editorial-text text-xl font-serif leading-snug italic font-normal">
              "Buda, prices za Tomato zita-spike next week because of heavy rain down south. 
              Kama unazo kwa shamba, hang in there just a few days uuze at a higher margin."
            </p>
            <div className="mt-6 w-12 h-[1px] bg-editorial-secondary"></div>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-8">
        <div className="bg-white border border-editorial-border rounded-[40px] p-10 shadow-sm min-h-[400px] flex flex-col">
          <div className="mb-8">
             <h2 className="text-[12px] font-bold text-editorial-muted uppercase tracking-[0.2em] font-sans mb-1">Historical Fluidity</h2>
             <p className="text-stone-400 text-xs font-serif italic">Price shifts recorded over the last quarter.</p>
          </div>
          
          <div className="flex-1 w-full min-h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trends[0].history}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E6E2DF" opacity={0.5} />
                <XAxis 
                  dataKey="date" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fill: '#8C837C', fontFamily: 'Inter' }} 
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fontSize: 10, fill: '#8C837C', fontFamily: 'Inter' }}
                  tickFormatter={(value) => `${value/1000}k`}
                />
                <Tooltip 
                  contentStyle={{ 
                    borderRadius: '0px', 
                    border: '1px solid #E6E2DF',
                    backgroundColor: '#FDFCFB',
                    boxShadow: 'none',
                    fontFamily: 'Playfair Display'
                  }}
                  formatter={(value: number) => [`KSh ${value.toLocaleString()}`, 'Rate']}
                />
                <Line 
                  type="monotone" 
                  dataKey="price" 
                  stroke="#526D4E" 
                  strokeWidth={2} 
                  dot={{ r: 3, fill: '#526D4E', strokeWidth: 0 }}
                  activeDot={{ r: 6, strokeWidth: 2, stroke: '#FDFCFB' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="p-8 border border-editorial-border rounded-xl">
          <p className="text-[10px] text-editorial-muted leading-relaxed uppercase tracking-[0.2em] font-sans font-bold mb-3 italic">Strategy Outlook</p>
          <p className="text-lg font-serif text-editorial-text leading-relaxed italic">
            Export demand for beans is projected to increase by 12% in the EAC region. Sell half now, keep half for June to maximize seasonal yield.
          </p>
        </div>
      </div>
    </div>
  );
};
